//Array of db.json

export interface ProductsIn {
  id: number,
  name: string,
  price: number,
  description: string,
  info:string
  origine:string,
  eta:string,
  razza:string,
  titolo:string,
  elemento:string,
  natura:string,
  altezza:string,
  peso:string,
  rarita:string,
  stampa:string,
  tipo:string,
  edizione:string,
  mazzo:string,
  effetto:string,
  utilizzo:string

}
