import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ProductsIn } from 'src/app/products-in.products-in';
import { ServiceService } from 'src/app/service.service';

@Component({
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss'],
})
export class CartComponent implements OnInit {
  id!: number;
  sub!: Subscription;
  productCart!: ProductsIn[];

  constructor(private Service: ServiceService) {}

  //Show Cart forum and clear

  buy(form: any) {
    form.value.carrello = this.productCart;
    console.log(form.value);
    this.Service.clear();
    this.productCart = this.Service.take();
    form.reset();
  }

  ngOnInit(): void {
    this.productCart = this.Service.take();
  }
  productList!: ProductsIn;
}
