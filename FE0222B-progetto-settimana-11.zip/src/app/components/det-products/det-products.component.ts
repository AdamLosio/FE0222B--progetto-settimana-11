import { Component, OnInit } from '@angular/core';
import { RouterModule, Params, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { ServiceService } from 'src/app/service.service';
import { HttpParams } from '@angular/common/http';
import { ProductsIn } from 'src/app/products-in.products-in';

@Component({
  templateUrl: './det-products.component.html',
  styleUrls: ['./det-products.component.scss'],
})
export class DetProductsComponent implements OnInit {
  constructor(
    private Service: ServiceService,
    private router: ActivatedRoute
  ) {}
  id!: number;
  sub!: Subscription;
  productList!: ProductsIn;

  ngOnInit(): void {
    this.product();
  }

  //Upgrade URL

  product() {
    this.sub = this.router.params.subscribe((params: Params) => {
      this.id = +params['id'];
      this.Service.getP(this.id).subscribe((productList) => {
        this.productList = productList;
      });
    });
  }

  addCart(id: number) {
    this.Service.getC(id);
    this.Service.con();
  }
}
