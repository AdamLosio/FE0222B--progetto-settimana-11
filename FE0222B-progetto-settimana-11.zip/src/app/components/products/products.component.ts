import { Component, Input, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ProductsIn } from 'src/app/products-in.products-in';
import { ServiceService } from 'src/app/service.service';

@Component({
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss'],
})
export class ProductsComponent implements OnInit {
  sub!: Subscription;

  constructor(private Service: ServiceService) {}

  productList!: ProductsIn[];

  //Take and show Array in console.log

  ngOnInit(): void {
    this.sub = this.Service.get().subscribe((productList) => {
      this.productList = productList;
      console.log(this.productList);
    });
  }
}
