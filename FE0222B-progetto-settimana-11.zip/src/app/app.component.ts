import { Component, OnInit } from '@angular/core';
import { ServiceService } from './service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})

//Adam Losio FE0222B
export class AppComponent implements OnInit {
  title = 'FE0222B-progetto-settimana-11';
  //Adam Losio FE0222B

  constructor(private Service: ServiceService) {}

  ngOnInit(): void {}
}
