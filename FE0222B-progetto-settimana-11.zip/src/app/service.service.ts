import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ProductsIn } from './products-in.products-in';

@Injectable({
  providedIn: 'root',
})

//URL Site

export class ServiceService {
  urlSite = 'http://localhost:4201';

  constructor(private http: HttpClient) {}

// productCart = ProductsIn = Array

  productCart: ProductsIn[] = [];

  //Starter number of the cart

  counter: number = 0;

  //Get id product

  get() {
    return this.http.get<ProductsIn[]>(this.urlSite + '/products');
  }

  //Get id product

  getP(id: number) {
    return this.http.get<ProductsIn>(this.urlSite + '/products' + '/' + id);
  }

  //Get id from card

  getC(id: number) {
    this.http
      .get<ProductsIn>(this.urlSite + '/products' + '/' + id)
      .subscribe((object) => {
        this.productCart.push(object);
      });
    console.log(this.productCart);
  }
  //Counter Cart
  con() {
    this.counter++;
  }

  //Take products
  take() {
    return this.productCart;
  }

  //Clear Cart
  clear() {
    this.productCart = [];
    this.counter = 0;
  }
}
